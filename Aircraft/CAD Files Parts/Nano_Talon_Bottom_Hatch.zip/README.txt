                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2863724
Nano Talon Bottom Hatch by Techdragonz is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

If your bottom hatch ever breaks or you want one just as a spare, look no further!
 
This bottom hatch can be 3D-printed and it's modeled to fit the hatch perfectly!
Follows the curvature of the original hatch.

If you have any suggestions on what should be added in the future, please let me know!


Weight: 25-35grams
Printing time: 3h
No support needed!
2 parts that can be glued together (with e.g. CA glue)

NOTICE: Work in Progress! Curves don't align 100% (Pretty close though) with the fuselage but the hatch fits and is functional! Updates coming in the following days.


# Print Settings

Printer: JGaurora A3S
Rafts: Doesn't Matter
Supports: No
Resolution: .2mm
Infill: 15%

# Post-Printing

* Trim away the brim
* Glue the 2 parts toghether
* Put in the magnets
* Done